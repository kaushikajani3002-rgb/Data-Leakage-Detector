
import pandas as pd
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score

data = pd.DataFrame({'x1': range(100), 'x2': range(100), 'y':[0,1]*50})

X = data[['x1','x2']]
y = data['y']

model = LogisticRegression()
model.fit(X, y)
cross_val_score(model, X, y)
